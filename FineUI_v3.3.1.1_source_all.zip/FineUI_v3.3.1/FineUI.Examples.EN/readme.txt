


First, copy the following folders to current folder:
1. ..\ExtAspNet.Examples\images
2. ..\ExtAspNet.Examples\icon
3. ..\ExtAspNet.Examples\theme
4. ..\ExtAspNet.Examples\fckeditor


Second, we need build extjs folder by ourselves:

1. Download extjs v3.4.1.1 from http://www.sencha.com/products/extjs3/download/
2. Go to folder ..\FineUI.Examples\extjs_builder
3. Copy all the files inside extjs_v3.4.1.1 folder into extjs_source_all
4. Run build.bat, this will generate the "extjs" folder directly under ..\FineUI.Examples
5. Copy the generated "extjs" folder into FineUI.Examples.EN folder
6. Done

