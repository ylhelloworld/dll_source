#ifndef VMEVENT_INVALIDSTATE_H_
#define VMEVENT_INVALIDSTATE_H_

#include "common.h"
#include "main.h"
#include "vmmhelper.h"


int handleInvalidEntryState(pcpuinfo currentcpuinfo,VMRegisters *vmregisters);

#endif /*VMEVENT_INVALIDSTATE_H_*/
