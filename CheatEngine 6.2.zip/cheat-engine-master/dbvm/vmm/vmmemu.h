#include "main.h"

#ifndef VMMEMU_H_
#define VMMEMU_H_

int emulatevm86(unsigned char *instructionpointer, VMRegisters *registers);

#endif
