#ifndef MULTICORE_H_
#define MULTICORE_H_

extern volatile unsigned int cpucount;
unsigned int initAPcpus(void);

#endif /*MULTICORE_H_*/
