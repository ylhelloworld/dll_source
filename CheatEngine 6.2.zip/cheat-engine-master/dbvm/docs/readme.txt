Write vmdisk.img to a floppy disk or burn vmcd.iso to cd and boot off it. 
When it's done loading remove the disk and your system will boot further

To make use of vmcall you need to provide it with 2 passwords, the defaults
are:
password1 : 0x76543210
password2 : 0xfedcba98

But can be changed during runtime.

System requirements:
Intel Core2Duo and higher, or a Intel DualCore 9x0. Other variants won't work
At least 16MB ram

If you have a AMD and want a version for those systems, then please donate $2000 to dark_byte@hotmail.com with paypal

Name suggestions for this tool are appreciated.
