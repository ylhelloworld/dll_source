#ifndef OSSPECIFIC_H_
#define OSSPECIFIC_H_

#include "vmmhelper.h"

int getpid(pcpuinfo currentcpuinfo);

#endif /*OSSPECIFIC_H_*/
