#include "common.h"

extern PARD fakeARD;
int ARDcount;

void sendARD(void);
void initARDcount(void);
