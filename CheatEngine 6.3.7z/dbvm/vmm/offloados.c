/*
 * offloados.c
 *
 *  Created on: Sep 2, 2009
 *      Author: erich
 *      Description: Contains the entry point a guest os can call which will cause it to get off-loaded into vmm mode
 */


//the startup info region must have been setup properly first
void offloados(void)
{

}
